package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.BoardDto;
import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.BoardService;
import com.ssafy.edu.vue.service.EmployeeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

//http://localhost:8197/humans/swagger-ui.html
@CrossOrigin(origins = {"*"}, maxAge = 6000)
@RestController
@RequestMapping("/api")
@Api(value="SSAFY2", description="SSAFY Resouces Management 2019")
public class BoardController {
	
	public static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardService  boardService; 


    @ApiOperation(value = "모든 게시판의 정보를 반환한다.", response = List.class)
	@RequestMapping(value = "/findAllBoard", method = RequestMethod.GET)
	public ResponseEntity<List<BoardDto>> findAllBoard() throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<BoardDto> boards = boardService.findAllBoard();
		if (boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<BoardDto>>(boards, HttpStatus.OK);
	}

    @ApiOperation(value = "입력된 제목을 가진 게시글을 찾아온다.", response = List.class)
	@RequestMapping(value = "/findBoardBytitle", method = RequestMethod.GET)
	public ResponseEntity<List<BoardDto>> findBoardBytitle(@PathVariable String title) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<BoardDto> boards = boardService.findBoardBytitle(title);
		if (boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<BoardDto>>(boards, HttpStatus.OK);
	}
    @ApiOperation(value = "입력된 번호를 가진 게시글을 찾아온다.", response = List.class)
	@RequestMapping(value = "/findBoardByidx/{idx}", method = RequestMethod.GET)
	public ResponseEntity<List<BoardDto>> findBoardByidx(@PathVariable int idx) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<BoardDto> boards = boardService.findBoardByidx(idx);
		if (boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<BoardDto>>(boards, HttpStatus.OK);
	}
    @ApiOperation(value = "게시글을 등록한다.", response = List.class)
	@RequestMapping(value = "/addBoard", method = RequestMethod.POST)
	public ResponseEntity<List<BoardDto>> addBoard(@RequestBody BoardDto dto) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		boardService.addBoard(dto);
		
		return new ResponseEntity<List<BoardDto>>( HttpStatus.OK);
	}
    @ApiOperation(value = "게시글을 삭제한다.", response = List.class)
	@RequestMapping(value = "/deleteBoard/{idx}", method = RequestMethod.GET)
	public ResponseEntity<List<BoardDto>> deleteBoard(@PathVariable int idx) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		boardService.deleteBoard(idx);
		
		return new ResponseEntity<List<BoardDto>>(HttpStatus.OK);
	}
    @ApiOperation(value = "게시글을 수정한다.", response = List.class)
	@RequestMapping(value = "/updateBoard", method = RequestMethod.POST)
	public ResponseEntity<List<BoardDto>> updateBoard(@RequestBody BoardDto dto) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		boardService.updateBoard(dto);
		
		return new ResponseEntity<List<BoardDto>>(HttpStatus.OK);
	}

}
