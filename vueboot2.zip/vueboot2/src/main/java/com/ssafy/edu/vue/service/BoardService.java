package com.ssafy.edu.vue.service;

import java.util.List;

import com.ssafy.edu.vue.dto.BoardDto;

public interface BoardService {
	List<BoardDto> findAllBoard() throws Exception;
	
	public List<BoardDto> findBoardBytitle(String title) throws Exception;
	public List<BoardDto> findBoardByidx(int idx) throws Exception;
	public void addBoard(BoardDto board) throws Exception;
	public void deleteBoard(int idx) throws Exception;
	public void updateBoard(BoardDto board) throws Exception;

	
}
