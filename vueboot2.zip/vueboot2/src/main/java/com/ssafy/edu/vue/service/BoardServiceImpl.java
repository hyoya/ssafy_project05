package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.vue.dao.SSAFyDaoImpl;
import com.ssafy.edu.vue.dto.BoardDto;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	SSAFyDaoImpl BoardDao;

	@Override
	public List<BoardDto> findAllBoard() throws Exception {
		// TODO Auto-generated method stub
		return BoardDao.findAllBoard();
	}

	@Override
	public List<BoardDto> findBoardBytitle(String title) throws Exception {
		// TODO Auto-generated method stub
		return BoardDao.findBoardBytitle(title);
	}

	@Override
	public List<BoardDto> findBoardByidx(int idx) throws Exception {
		return BoardDao.findBoardByidx(idx);
	}

	@Override
	public void addBoard(BoardDto board) throws Exception {
		BoardDao.addBoard(board);
	}

	@Override
	public void deleteBoard(int idx) throws Exception {
		// TODO Auto-generated method stub
		BoardDao.deleteBoard(idx);
	}

	@Override
	public void updateBoard(BoardDto board) throws Exception {
		// TODO Auto-generated method stub
		BoardDao.updateBoard(board);
	}

}
