package com.ssafy.edu.vue.dto;

public class BoardDto {
	private int idx;
	private String title;
	private String content;
	private String user;
	private String wdate;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getWdate() {
		return wdate;
	}
	public void setWdate(String wdate) {
		this.wdate = wdate;
	}
	public BoardDto(int idx, String title, String content, String user, String wdate) {
		super();
		this.idx = idx;
		this.title = title;
		this.content = content;
		this.user = user;
		this.wdate = wdate;
	}
	public BoardDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
